'use strict'

console.clear();

var [a, b] = ["Hola, ", "Mundo"];
console.log(a); 
console.log(b);

var obj = { nombre: "Fernando", apellido: "Ibarra" };
var { nombre, apellido } = obj;

console.log(nombre);