'use strict'

var ejemplo_1 = 12;
let ejemplo_2 = 13;

const CONSTANTE_PI = 3.141516;

console.log('Declarada con Var: ' + ejemplo_1);
console.log('Declarada con let: ' + ejemplo_1);

console.log('Declaradando Constante: ' + CONSTANTE_PI);