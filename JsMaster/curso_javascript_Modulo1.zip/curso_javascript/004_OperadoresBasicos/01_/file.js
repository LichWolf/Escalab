'use strict'

console.clear();

var num1 = 5;
var num2 = 5;
var Resultado = 0;

// Suma
Resultado = num1 + num2;
console.log('Resultado de la Suma: ' + Resultado);

// Resta
Resultado = num1 - num2;
console.log('Resultado de la Resta: ' + Resultado);

// Multiplicacion
Resultado = num1 * num2;
console.log('Resultado de la Multiplicacion: ' + Resultado);

// Division
Resultado = num1 / num2;
console.log('Resultado de la Division: ' + Resultado);

// Modulo Aritmetico
Resultado = num1 % 2;
console.log('Resultado del Modulo Aritmetico: ' + Resultado);

// Incremento
console.log('Incremento: ' + Resultado++);

// Decremento
console.log('Incremento: ' + Resultado--);