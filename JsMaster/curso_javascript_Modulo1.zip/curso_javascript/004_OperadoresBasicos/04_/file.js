'use strict'

console.clear();

var num1 = 5;
var num2 = 5;

console.log(num1 += num2);
console.log(num1 -= num2);
console.log(num1 /= num2);
console.log(num1 *= num2);
console.log(num1 %= num2);
console.log(num1 &= num2);
console.log(num1 ^= num2);
