'use strict'

console.clear();

var valor_verdadero = true;
var valor_falso = false;

// Valor de Negacion
console.log(!valor_verdadero);

// Conjuncion logica AND ( && ) 
console.log(valor_verdadero && valor_falso);

// Conjuncion logica OR ( || ) 
console.log(valor_verdadero || valor_falso);

