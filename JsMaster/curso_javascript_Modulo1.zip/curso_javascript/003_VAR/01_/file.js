'use strict'

console.clear();

// Modo Normal (recomendado para JS)
var primerNumero;
// Modo Desarrollo Pascal
var PrimerNumero;
// Modo Serpiente
var primer_numero;

// - Puede contener Letras, Digitos, Numeros y _ , $
var miValor1, matematico$
// - No puede iniciar con un digito
var matematico;
// - Puede iniciar con  _ o $
var _marcas, $rangos;
// - Los nombres son sensibles a Minusculas y Mayusculas
var x, X;
// - No pueden ser palabras reservadas
var varNombre;