'use strict'

console.clear();

var mVariable //Sin valor guardado
console.log(mVariable)

mVariable = null // Guarda un valor NULL
console.log(mVariable)