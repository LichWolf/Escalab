'use strict'

console.clear();

var miPrimerCadena = "Yo amo JavaScript";
console.log(typeof(miPrimerCadena));

var miSegundaCadena = 'Vamos a aprender JavaScript juntos'
console.log(typeof(miSegundaCadena));

var dobleComillayCadenas = "Esto es una cadena de \"JavaScript\""
console.log(dobleComillayCadenas)

var simpleComillayCadenas = 'Esto es una cadena de \'JavaScript\''
console.log(simpleComillayCadenas)

var dobleComillayCadenas2 = "Esto es una cadena de 'JavaScript' "
var simpleComillayCadenas2 = 'Esto es una cadena de "JavaScript" '